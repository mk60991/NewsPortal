
                <footer class="footer text-right">
                   2018 © Developed by PHPGurukul.
                </footer>
